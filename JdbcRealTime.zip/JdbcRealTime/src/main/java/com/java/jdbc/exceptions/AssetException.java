package com.java.jdbc.exceptions;

// Custom exception class for Asset Management
public class AssetException extends Exception {

    // Default constructor
    public AssetException() {
        super();
    }

    
}
